#ifndef dice_h
#define dice_h

class Dice{
    public:
        Dice();
        int roll();
};


#endif